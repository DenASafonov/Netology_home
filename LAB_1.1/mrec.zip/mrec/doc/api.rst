=================
API documentation
=================

.. toctree::
    :maxdepth: 5

    mrec



Indices
-------
- :ref:`genindex`
- :ref:`modindex`
