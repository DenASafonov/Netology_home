mrec.examples Package
=====================

:mod:`train` Module
-------------------

.. automodule:: mrec.examples.train
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`predict` Module
---------------------

.. automodule:: mrec.examples.predict
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`evaluate` Module
----------------------

.. automodule:: mrec.examples.evaluate
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`filename_conventions` Module
----------------------------------

.. automodule:: mrec.examples.filename_conventions
    :members:
    :undoc-members:
    :show-inheritance:

