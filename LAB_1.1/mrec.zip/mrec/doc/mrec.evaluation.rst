mrec.evaluation Package
=======================

:mod:`preprocessing` Module
---------------------------

.. automodule:: mrec.evaluation.preprocessing
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`metrics` Module
---------------------

.. automodule:: mrec.evaluation.metrics
    :members:
    :undoc-members:
    :show-inheritance:

