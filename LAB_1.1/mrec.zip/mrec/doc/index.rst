.. include:: ../README.rst

Contents
--------

.. toctree::
    :maxdepth: 1

    quickstart
    preparation
    training
    hybrid
    evaluation
    aws
    api


