mrec.mf Package
===============

:mod:`wrmf` Module
------------------

.. automodule:: mrec.mf.wrmf
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`warp` Module
------------------

.. automodule:: mrec.mf.warp
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`warp2` Module
-------------------

.. automodule:: mrec.mf.warp2
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`recommender` Module
-------------------------

.. automodule:: mrec.mf.recommender
    :members:
    :undoc-members:
    :show-inheritance:

 Subpackages
------------

.. toctree::

    mrec.mf.model

