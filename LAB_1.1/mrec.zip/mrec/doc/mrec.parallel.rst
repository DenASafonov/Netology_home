mrec.parallel Package
=====================

:mod:`item_similarity` Module
-----------------------------

.. automodule:: mrec.parallel.item_similarity
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wrmf` Module
------------------

.. automodule:: mrec.parallel.wrmf
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`warp` Module
------------------

.. automodule:: mrec.parallel.warp
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`predict` Module
---------------------

.. automodule:: mrec.parallel.predict
    :members:
    :undoc-members:
    :show-inheritance:
