mrec.item_similarity Package
============================

:mod:`slim` Module
------------------

.. automodule:: mrec.item_similarity.slim
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`knn` Module
-----------------

.. automodule:: mrec.item_similarity.knn
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`precomputed` Module
-------------------------

.. automodule:: mrec.item_similarity.precomputed
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`recommender` Module
-------------------------

.. automodule:: mrec.item_similarity.recommender
    :members:
    :undoc-members:
    :show-inheritance:

